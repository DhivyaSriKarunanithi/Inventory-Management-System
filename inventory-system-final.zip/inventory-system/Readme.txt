To run the project:

1. Open XAMPP and start Apache and MySQL.
2. Go to http://localhost/phpmyadmin in Chrome.
3. In the left sidebar, navigate to the "inventory" database and then to the "user" table.
4. Notice the "role" column in the user table.
5. Open the Inventory Management project in Chrome by clicking the relevant icon or link.
6. The project is now ready to use.