</div> <!-- close container -->
<footer class="bg-dark text-white text-center mt-5 p-3">
    &copy; <?= date('Y') ?> Inventory Management System. All rights reserved.
</footer>
<?php include 'footer.php'; ?>

</body>
</html>
